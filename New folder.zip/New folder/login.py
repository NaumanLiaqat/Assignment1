
from appJar import gui
from kkk import *
from quizt import quiz
from student import student
import yappi
import os


# Example of a semi-structured application
class MyApplication():
    # Build the GUI
    def Prepare(self, app):
        # Form GUI
        app.setTitle("Login Form")
        app.setFont(20)
        app.setStopFunction(self.BeforeExit)

        # Add labels & entries
        # in the correct row & column
        app.addLabel("userLab", "Username:", 0, 0)
        app.addEntry("username", 0, 1)
        app.addLabel("passLab", "Password:", 1, 0)
        app.addSecretEntry("password", 1, 1)
        app.addButtons(["Submit", "Cancel"], self.Submit, colspan=2)
        app.setFocus("username")
        return app

    # Build and Start your application
    def Start(self):
        # Creates a UI
        app = gui("Login Form")
        # Run the prebuild method that adds items to the UI
        app = self.Prepare(app)

        # Make the app class-accesible
        self.app = app

        # Start appJa
        app.go()

    # Callback execute before quitting your app
    def BeforeExit(self):
        return self.app.yesNoBox("Confirm Exit", "Are you sure you want to exit the application?")

    # Define method that is executed when the user clicks on the submit buttons
    # of the form
    def Submit(self, btnName):
        if btnName == "Submit":
            username = self.app.getEntry("username")
            password = self.app.getEntry("password")
            # Very stupid login system (both strings equal to ourcodeworld)
            for i in range(0, len(string)):
                if username == string[i][1] and password == string[i][2] and string[i][3] == "Teacher":
                    self.app.infoBox("Logged in", "You are now logged in as a Teacher")
                    self.app.removeAllWidgets()
                    quiz(self.app)

                    return
                elif username == string[i][1] and password == string[i][2] and string[i][3] == "Student":
                    self.app.infoBox("Logged in", "You are now logged in as a Student")
                    self.app.removeAllWidgets()
                    student(self.app)
                    return

            self.app.infoBox("Invalid Entry!, Rerun the application!")

            return 0


        if btnName == "Cancel":
            self.app.stop()

# Run the application
# `python main.py`


if __name__ == '__main__':
    yappi.start()

    # Create an instance of your application
    App = MyApplication()
    # Start your app !
    App.Start()
    yappi.get_func_stats().print_all()
    yappi.get_thread_stats().print_all()
    print yappi.get_mem_usage()