from appJar import gui
from kkk import *
class student:
    def __init__(self,app):
        self.app = app
        self.x = 0
        self.i = 0
        self.j = 0
        self.score = 0
        self.app.addLabel("attempt", "Press Start button to attempt the quiz!", 0, 0)
        self.app.addButton("Start Quiz", self.type)

    def type(self, app):
            self.app.removeAllWidgets()
            self.app.addButtons(["MCQS", "T/F", "Numeric"], self.ju, colspan=3)


    def start(self,button):
        self.app.removeAllWidgets()
            #for x in range(0, len(self.fet)):
    def show(self):
        if self.button == "MCQS":
            a = self.fet[self.x][0]
            self.app.addLabel("fun", "Question:", 0, 0)
            self.app.addLabel(a, a, 1, 0)
            b = self.fet[self.x][1]
            self.app.addRadioButton("opt1", b)
            # self.app.addLabel("opt1", b, 5, 0)
            c = self.fet[self.x][2]
            self.app.addRadioButton("opt1", c)
            d = self.fet[self.x][3]
            self.app.addRadioButton("opt1", d)
            e = self.fet[self.x][4]
            self.u = self.fet[self.x][5]
            self.app.addRadioButton("opt1", e)
            self.app.addButton("Submit", self.match)

        elif self.button == "T/F":

            a = self.rows[self.i][0]
            self.app.addLabel("fun", "Question:", 3, 0)
            self.app.addLabel(a, a, 4, 0)
            b = self.rows[self.i][1]
            self.app.addRadioButton("opt1", b)

            c = self.rows[self.i][2]
            self.app.addRadioButton("opt1", c)
            d = self.rows[self.i][3]
            self.d = d
            self.app.addButton("Submit", self.matchtf)


        else:
            a = self.things[self.j][0]
            self.app.addLabel("fun1", "Question:", 0, 0)
            self.app.addLabel(a, a, 1, 0)
            self.app.addLabel("a", "Type your answer:", 2, 0)
            self.app.addEntry("ans", 2, 1)

            self.t = self.things[self.j][1]
            self.app.addButton("Submit", self.matchnum)


        self.app.addButtons(["MCQS", "T/F", "Numeric"], self.ju, colspan=3)

        return

    def ju(self,button):
        self.button= button;
        print button
        cur = db.cursor()
        if button == "MCQS":
            cur.execute("SELECT * FROM  quiz")
            fet = cur.fetchall()
        # print self.fet
            self.fet = fet
            self.app.removeAllWidgets()
            self.show()

        elif button == "T/F":
            cur.execute("SELECT * FROM  tf")
            rows= cur.fetchall()
            self.rows = rows
            self.app.removeAllWidgets()
            self.show()
        else:
            cur.execute("SELECT * FROM  numericqs")
            things = cur.fetchall()
            self.things = things
            self.app.removeAllWidgets()
            self.show()

    def match(self, app):

        r = self.app.getRadioButton("opt1")

        if r == self.u:
            self.app.infoBox("Congratulations!!!", "Right Answer!")
            self.score += 1
            self.app.infoBox("SCORE", self.score)
        else:
            self.app.infoBox("SORRY !", "Wrong Answer!!")
            self.app.infoBox("SCORE", self.score)
        self.x +=1
        self.app.removeAllWidgets()
        if self.x < len(self.fet):
            self.show()

    def matchtf(self, app):
        r = self.app.getRadioButton("opt1")
        if r == self.d:
            self.app.infoBox("Congratulations!!!", "Right Answer!")
            self.score += 1
            self.app.infoBox("SCORE", self.score)
        else:
            self.app.infoBox("SORRY !", "Wrong Answer!!")
            self.app.infoBox("SCORE", self.score)
        self.i += 1
        self.app.removeAllWidgets()
        if self.i < len(self.rows):
            self.show()

    def matchnum(self, app):
        s = self.app.getEntry("ans")
        e = int(s)
        if e == self.t:

            self.app.infoBox("Congratulations!!!", "Right Answer!")
            self.score += 1
            self.app.infoBox("SCORE", self.score)
        else:
            self.app.infoBox("SORRY !", "Wrong Answer!!")
            self.app.infoBox("SCORE", self.score)

        self.j += 1
        self.app.removeAllWidgets()
        if self.j < len(self.things):
            self.show()
    def next(self):
        print "s"
        #self.x=self.x+1
        #self.app.start()







if __name__ == '__main__':

    app = gui("Quiz!!!", "400x500")
    a = student(app)
    app.setBg("grey")
    app.setFont(12)
    app.go()