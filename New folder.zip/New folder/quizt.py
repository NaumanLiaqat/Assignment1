from appJar import gui
from kkk import *


class quiz:

    def __init__(self,app):
        self.app = app
        self.app.addLabel("QUESTIONs", "Press ADD button to set the quiz!", 4, 0)
        self.app.addButton("Add Quiz", self.types)

    def types(self,app):
        self.app.removeAllWidgets()
        self.app.addButtons(["MCQS","T/F", "Numeric"], self.cl, colspan=3)



    def press(app, rb):
        print(app.getRadioButton("mcqs"))

    def cl(self, button):
        self.app.removeAllWidgets()
        if button == "MCQS":
            self.app.clearAllEntries()
            self.app.addButtons(["MCQS", "T/F", "Numeric"], self.cl, colspan=3)
            self.app.addLabel("QUESTION","Question:", 15, 0)
            self.app.addEntry("QUESTION", 16, 0)
    #        self.app.setLocation("CENTER")
            self.app.addLabel("A", "(A)", 17, 0)
            self.app.addEntry("A", 17, 1)
            self.app.addLabel("B", "(B)", 18, 0)
            self.app.addEntry("B", 18, 1)
            self.app.addLabel("C", "(C)", 19, 0)
            self.app.addEntry("C", 19, 1)
            self.app.addLabel("D", "(D)", 20, 0)
            self.app.addEntry("D", 20, 1)
            self.app.addLabel("E", "Correct Answer", 21, 0)
            self.app.addEntry("E", 21, 1)
            # call this function, when the RadioButton changes
            # app.setRadioButtonChangeFunction("mcqs", press)
            self.app.addButton("CONFIRM", self.adder)
            return
        elif button == "T/F":
            self.app.clearAllEntries()
            self.app.addButtons(["MCQS", "T/F", "Numeric"], self.cl, colspan=3)
            self.app.addLabel("question", "T/F Question:", 17, 0)
            self.app.addEntry("Question", 18, 0)
            #        self.app.setLocation("CENTER")
            self.app.addLabel("a", "(A)", 19, 0)
            self.app.addEntry("a", 19, 1)
            self.app.addLabel("b", "(B)", 20, 0)
            self.app.addEntry("b", 20, 1)
            self.app.addLabel("c", "Correct Answer", 21, 0)
            self.app.addEntry("c", 21, 1)
            self.app.addButton("Confirm", self.addertf)
        elif button == "Numeric":
            self.app.clearAllEntries()
            self.app.addButtons(["MCQS", "T/F", "Numeric"], self.cl, colspan=3)
            self.app.addLabel("questions", "Numeric Question:", 19, 0)
            self.app.addEntry("question", 20, 0)
            #        self.app.setLocation("CENTER")
            self.app.addLabel("q", "Correct Answer", 21, 0)
            self.app.addEntry("Answer", 21, 1)
            self.app.addButton("CONFIRM.", self.addern)
    def adder(self, app):
        question = self.app.getEntry("QUESTION")
        a = self.app.getEntry("A")
        b = self.app.getEntry("B")
        c = self.app.getEntry("C")
        d = self.app.getEntry("D")
        e = self.app.getEntry("E")

        cur.execute("INSERT INTO quiz VALUES (%s,%s,%s,%s,%s,%s)", (question, a, b, c, d, e))
        db.commit()
        self.app.infoBox("Added!!", "Data has been entered!")
        self.app.clearAllEntries()

    def addertf(self, app):

        question = self.app.getEntry("Question")
        a = self.app.getEntry("a")
        b = self.app.getEntry("b")
        c = self.app.getEntry("c")

        cur.execute("INSERT INTO tf VALUES (%s,%s,%s,%s)", (question, a, b, c))
        db.commit()
        self.app.infoBox("Added!!", "Data has been entered!")
        self.app.clearAllEntries()

    def addern(self, app):

        question = self.app.getEntry("question")
        a = self.app.getEntry("Answer")

        cur.execute("INSERT INTO numericqs VALUES (%s,%s)", (question, a))
        db.commit()
        self.app.infoBox("Added!!", "Data has been entered!")
        self.app.clearAllEntries()

if __name__ == '__main__':
    app = gui("Quiz!!!", "400x300")
    a = quiz(app)
    app.setBg("grey")
    app.setFont(12)
    app.go()
